# Deploy lên GitHub Pages

1. Đưa các file và thư mục trong dự án lên repository.
2. Trên GitHub, mở **Settings → Pages**.
3. Chọn **GitHub Actions** làm Build and deployment source.
4. Push lên nhánh `main`; workflow `.github/workflows/pages.yml` sẽ build artifact tĩnh và deploy.
5. Mở tab **Actions** để xem trạng thái.

Ứng dụng không cần backend để chạy các tính năng hiện có. Tài khoản và dự án vẫn nằm trong trình duyệt của người dùng.
