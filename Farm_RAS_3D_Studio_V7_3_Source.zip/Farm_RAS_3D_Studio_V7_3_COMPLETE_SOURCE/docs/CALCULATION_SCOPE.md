# Phạm vi tính toán

## Có trong bản hiện tại

- Thể tích làm việc bể tròn và chữ nhật.
- Tổng sinh khối và lượng thức ăn/ngày.
- Lưu lượng mục tiêu từ thể tích bể nuôi / thời gian tuần hoàn.
- HRT bể lắng.
- Tải TAN và thể tích giá thể biofilter theo tải thiết kế do người dùng nhập.
- Vận tốc ống, tổn thất ma sát Darcy–Weisbach, tổn thất cục bộ K tổng.
- Công suất thủy lực/điện sơ bộ từ TDH và hiệu suất.
- Nhu cầu oxy sơ bộ từ sinh khối và hệ số tiêu thụ nhập.

## Chưa mô hình hóa đầy đủ

- Giải mạng nhiều nhánh / manifold theo phương trình nút.
- Đường đặc tính bơm và điểm làm việc thực tế từ catalogue nhà sản xuất.
- NPSH, quá trình chuyển tiếp, búa nước, ống không đầy, siphon và khí kẹt.
- Tải BOD, nhu cầu oxy nitrification đầy đủ, NO₂/NO₃ và cân bằng CO₂.
- Hiệu quả UV từ UVT, liều theo lưu lượng và lão hóa bóng.
- Sizing máy thổi khí/đĩa phân phối từ đường cong áp suất-lưu lượng.

Các hệ số mẫu chỉ để demo. Người thiết kế phải thay bằng thông số được đo hoặc do nhà sản xuất xác nhận.
