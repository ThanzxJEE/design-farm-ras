# Tài khoản và lưu trữ

- Tài khoản được lưu cục bộ trong localStorage.
- Mật khẩu không lưu dạng rõ; ứng dụng lưu salt và hash PBKDF2-HMAC-SHA256.
- Phiên đăng nhập được lưu trong localStorage để giữ trạng thái đăng nhập khi tải lại trang.
- Dự án lưu dưới JSON localStorage; người dùng có thể xuất JSON để sao lưu.
- Không có Firebase, API server, khôi phục mật khẩu hoặc đồng bộ đa thiết bị trong bản này.

Đây là lớp xác thực demo phía client. Vì mã frontend và logic kiểm tra đều công khai, người có khả năng sửa mã có thể bỏ qua kiểm tra. Không sử dụng để bảo vệ tài nguyên riêng tư hoặc dữ liệu nhạy cảm.
