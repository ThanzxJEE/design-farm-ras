# Kiến trúc mã nguồn

## Luồng khởi động

`index.html` nạp CSS và `src/app.js` dưới dạng ES module. `app.js` là tầng điều phối giao diện: liên kết DOM, trạng thái editor, renderer 2D/3D, inspector, dashboard, sự kiện và luồng đăng nhập.

## Các module lõi

- `core/catalog.js`: metadata thiết bị, thông số mặc định và trường nhập.
- `core/calculations.js`: phép tính thể tích, sinh khối, thức ăn, lưu lượng, HRT, TAN, biofilter, oxy và cảnh báo.
- `core/hydraulics.js`: tính vận tốc và tổn thất cột áp theo Darcy–Weisbach với hệ số K tổng.
- `core/pipe-geometry.js`: tính vị trí cổng, định tuyến vuông góc và chiều dài ống; đầu ống bám theo thiết bị.
- `core/project-store.js`: chuẩn hóa JSON import và serialize snapshot.
- `core/storage.js`: thao tác JSON với localStorage có xử lý lỗi.
- `auth/auth-crypto.js`: PBKDF2-HMAC-SHA256 cho tài khoản cục bộ.

Một số phần UI vẫn tập trung trong `app.js` để giữ nguyên hành vi của bản V7.3 đã phát hành. Đây là dự án vanilla JavaScript, không phải React/Vue.
