# Checklist phát hành

- [ ] Chạy `npm run check`.
- [ ] Chạy `npm test`.
- [ ] Thử đăng ký, đăng xuất, đăng nhập trên trình duyệt sạch.
- [ ] Thử thêm/xóa/di chuyển thiết bị.
- [ ] Thử tạo ống và kéo thiết bị để kiểm tra đầu ống bám cổng.
- [ ] Thử chỉnh ống, xuất SVG và nhập/xuất JSON.
- [ ] Sao lưu JSON trước khi xóa dữ liệu trình duyệt.
- [ ] Đối chiếu lại thông số kỹ thuật trước khi sử dụng ngoài demo.
