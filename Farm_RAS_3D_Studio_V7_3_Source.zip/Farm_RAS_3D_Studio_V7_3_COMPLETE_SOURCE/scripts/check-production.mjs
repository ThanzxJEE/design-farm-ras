import { readFile, access, readdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { constants } from 'node:fs';

const mustExist = ['index.html', 'src/app.js', 'src/styles.css', 'src/core/catalog.js', 'src/core/calculations.js'];
for (const file of mustExist) await access(new URL(`../${file}`, import.meta.url), constants.R_OK);
const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
if (!html.includes('type="module"') || !html.includes('./src/app.js')) throw new Error('index.html chưa nạp app.js dưới dạng module');
const app = await readFile(new URL('../src/app.js', import.meta.url), 'utf8');
if (!app.includes("from './core/calculations.js'") || !app.includes("from './auth/auth-crypto.js'")) throw new Error('Thiếu import module lõi');
if (/(AIza[0-9A-Za-z_-]{30,}|BEGIN PRIVATE KEY|serviceAccount)/.test(app)) throw new Error('Có vẻ có secret/credential trong frontend');
async function walk(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = resolve(directory, entry.name);
    if (entry.isDirectory()) files.push(...await walk(full));
    else if (entry.isFile() && full.endsWith('.js')) files.push(full);
  }
  return files;
}
const sourceRoot = new URL('../src/', import.meta.url);
const jsFiles = await walk(new URL('../src/', import.meta.url).pathname);
for (const file of jsFiles) {
  const source = await readFile(file, 'utf8');
  for (const match of source.matchAll(/(?:from|import)\s*\(?\s*['\"](\.\.?\/[^'\"]+)['\"]/g)) {
    const target = resolve(dirname(file), match[1]);
    await access(target, constants.R_OK);
  }
}
console.log(`Production source check passed (${mustExist.length} core files; ${jsFiles.length} JavaScript files and local imports checked).`);
