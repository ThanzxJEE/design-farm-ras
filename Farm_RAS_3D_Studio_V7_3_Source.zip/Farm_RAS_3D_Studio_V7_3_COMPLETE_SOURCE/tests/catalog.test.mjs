import test from 'node:test';
import assert from 'node:assert/strict';
import { CATALOG, FIELDS, ROUND_TYPES, byType } from '../src/core/catalog.js';

test('catalog has unique equipment type identifiers', () => {
  const types = CATALOG.map(item => item.type);
  assert.equal(new Set(types).size, types.length);
  assert.ok(types.length >= 14);
  assert.ok(byType('fishTank'));
  assert.ok(byType('oxygenSource'));
});

test('equipment fields and defaults are present', () => {
  for (const item of CATALOG) {
    assert.ok(item.name);
    assert.ok(item.defaults && typeof item.defaults === 'object');
    assert.ok(Array.isArray(FIELDS[item.type]));
  }
  assert.ok(ROUND_TYPES.has('fishTank'));
});
