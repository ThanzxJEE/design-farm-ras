import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('entry HTML loads modular app and stylesheet', async () => {
  const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
  assert.match(html, /\.\/src\/styles\.css/);
  assert.match(html, /type="module" src="\.\/src\/app\.js"/);
});

test('app imports core modules and keeps mandatory auth gate', async () => {
  const app = await readFile(new URL('../src/app.js', import.meta.url), 'utf8');
  assert.match(app, /core\/calculations\.js/);
  assert.match(app, /core\/pipe-geometry\.js/);
  assert.match(app, /auth\/auth-crypto\.js/);
  assert.match(app, /initAuth\(\)/);
});
