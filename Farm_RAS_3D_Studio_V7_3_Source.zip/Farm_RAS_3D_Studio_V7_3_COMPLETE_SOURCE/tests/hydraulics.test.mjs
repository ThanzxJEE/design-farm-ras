import test from 'node:test';
import assert from 'node:assert/strict';
import { calculatePipeHydraulics } from '../src/core/hydraulics.js';

test('Darcy-Weisbach helper reports positive velocity and losses', () => {
  const result = calculatePipeHydraulics({ flowM3h: 8, diameterM: 0.09, pipeLengthM: 30, frictionFactor: 0.025, minorK: 8, staticHeadM: 2.5 });
  assert.ok(result.velocityMps > 0);
  assert.ok(result.frictionHeadM > 0);
  assert.ok(result.minorHeadM > 0);
  assert.ok(result.totalDynamicHeadM > 2.5);
  assert.ok(result.hydraulicPowerW > 0);
});

test('zero flow produces zero dynamic losses', () => {
  const result = calculatePipeHydraulics({ flowM3h: 0, diameterM: 0.09, pipeLengthM: 30, frictionFactor: 0.025, minorK: 8, staticHeadM: 2.5 });
  assert.equal(result.velocityMps, 0);
  assert.equal(result.totalHeadLossM, 0);
  assert.equal(result.totalDynamicHeadM, 2.5);
});
