import test from 'node:test';
import assert from 'node:assert/strict';
import { deriveAuthHash, authHex, authFromHex } from '../src/auth/auth-crypto.js';

test('hex encoding round-trips bytes', () => {
  const bytes = new Uint8Array([0, 1, 15, 16, 255]);
  assert.deepEqual(Array.from(authFromHex(authHex(bytes))), Array.from(bytes));
});

test('PBKDF2 hash is stable for same password/salt and changes with salt', async () => {
  const saltA = '00112233445566778899aabbccddeeff';
  const saltB = '10112233445566778899aabbccddeeff';
  const first = await deriveAuthHash('demo-password-123', saltA);
  const again = await deriveAuthHash('demo-password-123', saltA);
  const other = await deriveAuthHash('demo-password-123', saltB);
  assert.equal(first, again);
  assert.notEqual(first, other);
  assert.equal(first.length, 64);
});
