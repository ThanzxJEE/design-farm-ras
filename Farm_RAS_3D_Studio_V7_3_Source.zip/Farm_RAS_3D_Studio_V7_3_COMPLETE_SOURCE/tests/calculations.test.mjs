import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateSystem, volumeOf } from '../src/core/calculations.js';

const tank = { id: 'tank-1', type: 'fishTank', name: 'Bể demo', params: {
  diameter: 2, height: 1.2, waterLevel: 1, fishCount: 100, avgFishWeight: 0.5,
  feedRate: 2, ratedFlow: 20
}};
const settler = { id: 'settler-1', type: 'settlingTank', name: 'Lắng', params: {
  diameter: 1, height: 1.2, waterLevel: 1, designHRT: 0.1, ratedFlow: 20
}};
const pump = { id: 'pump-1', type: 'pump', name: 'Bơm', params: {
  ratedFlow: 20, head: 10, efficiency: 60, motorPower: 1
}};
const bio = { id: 'bio-1', type: 'biofilter', name: 'MBBR', params: {
  diameter: 1, height: 1.2, waterLevel: 1, mediaFraction: 50,
  specificSurfaceArea: 500, tanLoading: 0.2, ratedFlow: 20
}};
const settings = {
  turnoverHours: 0.5, staticHead: 2, pipeDiameter: 0.09, pipeLength: 20,
  minorK: 5, pumpEfficiency: 60, feedRate: 2, tanPerKgFeed: 0.03,
  oxygenConsumption: 0.35, oxygenEfficiency: 70, doCurrent: 5, doTarget: 6,
  frictionFactor: 0.025, maxVelocity: 2, maxHeadLoss: 5
};

test('round tank volume uses working water depth', () => {
  assert.ok(Math.abs(volumeOf(tank) - Math.PI) < 1e-10);
});

test('system calculation returns biomass, feed, flow and TAN', () => {
  const result = calculateSystem([tank, settler, pump, bio], [], settings);
  assert.equal(result.biomass, 50);
  assert.equal(result.feed, 1);
  assert.ok(Math.abs(result.flow - (Math.PI / 0.5)) < 1e-10);
  assert.ok(Math.abs(result.tan - 0.03) < 1e-10);
  assert.ok(result.velocity > 0);
  assert.ok(result.tdh >= result.staticHead);
});

test('missing treatment equipment produces warnings instead of crashing', () => {
  const result = calculateSystem([tank], [], settings);
  assert.ok(result.warnings.length > 0);
  assert.equal(result.status, 'Không phù hợp');
});
