import test from 'node:test';
import assert from 'node:assert/strict';
import { ROUND_TYPES } from '../src/core/catalog.js';
import { devicePipePort, buildPipeRoute, measurePipeLength } from '../src/core/pipe-geometry.js';

const a = { id: 'a', type: 'fishTank', x: 0, z: 0, rotation: 0, params: { diameter: 2 } };
const b = { id: 'b', type: 'drumFilter', x: 4, z: 0, rotation: 0, params: { width: 1, depth: 0.8 } };

test('circular device port lies on tank radius', () => {
  const point = devicePipePort(a, [4, 0], ROUND_TYPES);
  assert.ok(Math.abs(point[0] - 1) < 1e-10);
  assert.equal(point[1], 0);
});

test('route endpoints attach to current device footprints', () => {
  const pipe = { id: 'p', from: 'a', to: 'b', route: [[0, 0], [2, 1], [4, 0]] };
  const first = buildPipeRoute(pipe, [a, b], ROUND_TYPES);
  assert.ok(Math.abs(Math.hypot(first[0][0] - a.x, first[0][1] - a.z) - 1) < 1e-10);
  assert.ok(Math.abs(first[first.length - 1][0] - 3.5) < 1e-10);
  const moved = { ...b, x: 5 };
  const afterMove = buildPipeRoute(pipe, [a, moved], ROUND_TYPES);
  assert.notEqual(afterMove.at(-1)[0], first.at(-1)[0]);
  assert.ok(measurePipeLength(pipe, [a, b], ROUND_TYPES) > 0);
});
