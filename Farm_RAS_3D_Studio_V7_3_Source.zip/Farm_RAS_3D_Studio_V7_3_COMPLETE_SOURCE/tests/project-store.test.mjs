import test from 'node:test';
import assert from 'node:assert/strict';
import { CATALOG, byType } from '../src/core/catalog.js';
import { normalizeProjectData, createProjectSnapshot } from '../src/core/project-store.js';
import { uid, escNum } from '../src/core/utils.js';

const defaults = { turnoverHours: 0.5, pipeDiameter: 0.09 };

test('normalizer restores defaults and filters broken connection references', () => {
  const result = normalizeProjectData({
    projectName: 'Demo',
    devices: [{ id: 'd1', type: 'fishTank', params: { diameter: 2 }, x: '1', z: '2' }],
    connections: [{ id: 'p1', from: 'd1', to: 'missing' }, { id: 'p2', from: 'd1', to: 'd1', kind: 'water' }],
    settings: { turnoverHours: 1 },
    view: { planZoom: 5, mode: '3d' }
  }, { byType, createId: uid, safeNumber: escNum, defaultSettings: defaults });
  assert.equal(result.devices.length, 1);
  assert.equal(result.connections.length, 1);
  assert.equal(result.devices[0].params.height, byType('fishTank').defaults.height);
  assert.equal(result.settings.turnoverHours, 1);
  assert.equal(result.view.planZoom, 1.8);
  assert.equal(result.view.mode, '3d');
});

test('snapshot uses the expected project schema', () => {
  const state = { devices: [], connections: [], settings: defaults, viewMode: '2d', planZoom: 1 };
  const snapshot = createProjectSnapshot({ state, camera3: { yaw: 0 }, projectName: 'Test' });
  assert.equal(snapshot.format, 'FarmRAS3D');
  assert.equal(snapshot.projectName, 'Test');
  assert.deepEqual(snapshot.devices, []);
});
