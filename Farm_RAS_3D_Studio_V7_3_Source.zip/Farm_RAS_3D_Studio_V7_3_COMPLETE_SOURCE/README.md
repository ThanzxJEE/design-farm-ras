# Farm RAS 3D Studio V7.3

**Demo cục bộ:** mở `index.html` qua máy chủ tĩnh (`npm run dev`).

Farm RAS 3D Studio là công cụ thiết kế sơ bộ hệ thống nuôi thủy sản tuần hoàn (RAS). Ứng dụng hỗ trợ bố trí thiết bị trên mặt bằng 2D, xem mô hình 3D, kết nối đường ống, chỉnh sửa thông số và xem các phép tính kỹ thuật tham khảo.

![Màn hình đăng nhập](docs/login-preview.png)

![Màn hình thiết kế](docs/editor-preview.png)

## Bắt đầu

1. Cài Node.js 18 trở lên.
2. Chạy `npm install` (dự án không dùng thư viện runtime bên ngoài).
3. Chạy `npm run dev`.
4. Mở địa chỉ được in ở terminal, thường là `http://localhost:4173`.
5. Đăng ký tài khoản cục bộ hoặc đăng nhập trên trình duyệt hiện tại.
6. Dùng thư viện bên trái để thêm thiết bị; chọn thiết bị hoặc ống để chỉnh thông số.
7. Dùng `Quản lý → Mở JSON` để nạp mẫu trong `public/examples/`.

## Tài khoản và nơi lưu dữ liệu

| Thành phần | Cách hoạt động | Phạm vi |
|---|---|---|
| Đăng ký/đăng nhập | PBKDF2-HMAC-SHA256 với salt riêng; số vòng hiện tại 150.000 | Trình duyệt/origin đang dùng |
| Phiên đăng nhập | Lưu trạng thái phiên trong localStorage | Trình duyệt hiện tại |
| Dự án | JSON dự án được lưu trong localStorage; có thể xuất/nhập JSON | Trình duyệt hiện tại |
| Tài khoản cloud | Chưa tích hợp backend/Firebase | Không đồng bộ nhiều máy |

Đây là cơ chế đăng nhập cục bộ để demo, không phải hệ thống xác thực production. Mã nguồn frontend công khai trên GitHub Pages; không dùng cơ chế này để bảo vệ dữ liệu nhạy cảm. Xóa dữ liệu trình duyệt có thể làm mất tài khoản và dự án cục bộ. Hãy xuất JSON để sao lưu.

## Trình thiết kế

- Mặt bằng 2D có lưới tỷ lệ, kéo thả, xoay, nhân bản và xóa thiết bị.
- Chế độ xem 3D Canvas tự dựng, có thao tác xoay và phóng to/thu nhỏ.
- Thư viện thiết bị RAS: bể cá tròn/chữ nhật, bể lắng, Drum Filter, lọc cơ học, biofilter, bể chứa, bể thu bùn, tháp khử khí, bơm, blower, côn oxy, nguồn oxy, UV, van và đoạn ống.
- Kết nối đường ống có hướng; đầu ống tự bám theo thiết bị khi di chuyển.
- Chọn tuyến ống để chỉnh loại tuyến, đường kính, lưu lượng, chiều dài và các điểm gấp khúc.
- Lưu dự án cục bộ, xuất/nhập JSON, xuất sơ đồ SVG, báo cáo CSV và in PDF.

## Cấu trúc mã nguồn

```text
Farm_RAS_3D_Studio_V7_3_COMPLETE_SOURCE/
├── .github/workflows/       # CI và GitHub Pages
├── docs/                    # Kiến trúc, công thức, lưu trữ, triển khai
├── public/examples/          # Dữ liệu demo JSON và thông số
├── scripts/                 # Máy chủ tĩnh và kiểm tra production
├── src/
│   ├── app.js                # Điều phối giao diện và sự kiện
│   ├── auth/auth-crypto.js   # Hash mật khẩu cục bộ
│   ├── core/catalog.js      # Danh mục thiết bị và trường nhập
│   ├── core/calculations.js # Calculation Engine
│   ├── core/hydraulics.js   # Tổn thất ống Darcy-Weisbach
│   ├── core/pipe-geometry.js# Cổng thiết bị và định tuyến ống
│   ├── core/project-store.js# Chuẩn hóa/serialize JSON
│   ├── core/storage.js      # Adapter localStorage an toàn
│   ├── core/utils.js        # Hàm tiện ích dùng chung
│   └── styles.css           # CSS giao diện
├── tests/                   # Unit và smoke tests
├── index.html               # Trang chạy dạng source
└── standalone.html          # Bản HTML độc lập gốc
```

## Calculation Engine

| Hạng mục | Công thức tham khảo |
|---|---|
| Bể tròn | `V = π × (D/2)² × H nước` |
| Bể chữ nhật | `V = L × W × H nước` |
| Sinh khối | `Số cá × khối lượng trung bình/con` |
| Thức ăn | `Sinh khối × tỷ lệ thức ăn/ngày` |
| Lưu lượng tuần hoàn | `Q = tổng thể tích bể nuôi / thời gian tuần hoàn` |
| HRT | `HRT = thể tích bể lắng / lưu lượng` |
| TAN | `TAN = lượng thức ăn/ngày × hệ số TAN` |
| Biofilter | `V vật liệu cần = tải TAN / tải xử lý thiết kế` |
| Vận tốc ống | `v = Q/A` |
| Tổn thất ống | Darcy–Weisbach `f(L/D)v²/(2g) + K v²/(2g)` |
| Công suất bơm | `P = ρgQH/η` |

Các hệ số TAN, tải xử lý giá thể, tiêu thụ oxy, hiệu suất chuyển oxy và thông số bơm là dữ liệu đầu vào/giả định demo. Tính toán đường ống đang dùng tuyến tương đương, chưa giải đầy đủ mạng nhiều nhánh, NPSH, đường đặc tính Q-H hoặc tổn thất riêng từng thiết bị. Không dùng trực tiếp làm hồ sơ thi công khi chưa được kỹ sư chuyên môn thẩm định.

## Lệnh phát triển và kiểm thử

```bash
npm install
npm run dev
npm run check
npm test
npm run check:production
```

## GitHub Pages

Workflow `.github/workflows/pages.yml` triển khai thư mục gốc. Bật **Settings → Pages → GitHub Actions**. Khi đặt trong repo `design-3d-RAS-system`, URL dự kiến là `https://<username>.github.io/design-3d-RAS-system/`. Xem [docs/GITHUB_PAGES.md](docs/GITHUB_PAGES.md).

## Giới hạn và lưu ý

- Đăng nhập là cục bộ; không có backend, khôi phục mật khẩu, phân quyền hoặc đồng bộ tài khoản.
- Dữ liệu dự án trong localStorage không được mã hóa; không lưu thông tin nhạy cảm.
- Chức năng xem 3D là mô hình trực quan, không phải CFD.
- Cảnh báo chỉ đánh giá các giới hạn đã được mô hình hóa và nhập vào.
- Kết quả phải được kiểm tra lại bằng dữ liệu thiết bị thực và chuyên gia RAS trước khi xây dựng.

## License

Chưa gắn giấy phép mã nguồn. Chủ dự án cần thêm file `LICENSE` nếu muốn công bố quyền sử dụng, sửa đổi và phân phối.
