// Tính sơ bộ thủy lực ống áp lực theo Darcy–Weisbach.
// Đây là mô hình một tuyến tương đương, không phải bộ giải mạng nhiều nhánh.
const RHO_WATER = 1000; // kg/m³, giả định nước ngọt ở điều kiện thường
const GRAVITY = 9.81;   // m/s²

export function calculatePipeHydraulics({
  flowM3h,
  diameterM,
  pipeLengthM,
  frictionFactor,
  minorK,
  staticHeadM
}) {
  const flowM3s = Math.max(0, Number(flowM3h) || 0) / 3600;
  const diameter = Math.max(0.01, Number(diameterM) || 0.09);
  const area = Math.PI * diameter ** 2 / 4;
  const velocity = area > 0 ? flowM3s / area : 0;
  const factor = Math.max(0.0001, Number(frictionFactor) || 0.025);
  const length = Math.max(0, Number(pipeLengthM) || 0);
  const localK = Math.max(0, Number(minorK) || 0);
  const velocityHead = velocity ** 2 / (2 * GRAVITY);
  const frictionHead = factor * (length / diameter) * velocityHead;
  const minorHead = localK * velocityHead;
  const staticHead = Math.max(0, Number(staticHeadM) || 0);
  const totalHeadLoss = frictionHead + minorHead;
  return {
    flowM3s,
    diameterM: diameter,
    areaM2: area,
    velocityMps: velocity,
    velocityHeadM: velocityHead,
    frictionHeadM: frictionHead,
    minorHeadM: minorHead,
    totalHeadLossM: totalHeadLoss,
    staticHeadM: staticHead,
    totalDynamicHeadM: staticHead + totalHeadLoss,
    hydraulicPowerW: RHO_WATER * GRAVITY * flowM3s * (staticHead + totalHeadLoss)
  };
}
