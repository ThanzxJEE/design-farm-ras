// Chuẩn hóa file dự án JSON trước khi đưa vào state của giao diện.
export function createProjectSnapshot({ state, camera3, projectName }) {
  return {
    format: 'FarmRAS3D',
    version: 2,
    projectName: String(projectName || 'Dự án RAS'),
    devices: state.devices,
    connections: state.connections,
    settings: state.settings,
    view: {
      mode: state.viewMode,
      planZoom: state.planZoom,
      camera3
    },
    savedAt: new Date().toISOString()
  };
}

export function normalizeProjectData(data, { byType, createId, safeNumber, defaultSettings }) {
  if (!data || !Array.isArray(data.devices)) {
    throw new Error('File dự án không có danh sách thiết bị hợp lệ.');
  }

  const devices = [];
  for (const source of data.devices) {
    if (!source || !byType(source.type)) continue;
    const meta = byType(source.type);
    devices.push({
      id: String(source.id || createId()),
      type: source.type,
      name: String(source.name || meta.name),
      params: {
        ...meta.defaults,
        ...(source.params && typeof source.params === 'object' ? source.params : {})
      },
      x: safeNumber(source.x),
      z: safeNumber(source.z),
      rotation: safeNumber(source.rotation),
      labelSide: source.labelSide === 'above' ? 'above' : 'below'
    });
  }

  const ids = new Set(devices.map(device => device.id));
  const connections = (Array.isArray(data.connections) ? data.connections : [])
    .filter(connection => connection && ids.has(connection.from) && ids.has(connection.to))
    .map(connection => ({
      id: String(connection.id || createId()),
      from: connection.from,
      to: connection.to,
      ...(connection.kind ? { kind: connection.kind } : {}),
      ...(Array.isArray(connection.route) ? { route: connection.route } : {}),
      ...(connection.label ? { label: connection.label } : {}),
      ...(connection.flowLabel ? { flowLabel: true } : {}),
      ...(connection.flowM3h !== undefined ? { flowM3h: safeNumber(connection.flowM3h) } : {}),
      ...(connection.diameterLabel ? { diameterLabel: connection.diameterLabel } : {}),
      ...(connection.diameterMm !== undefined ? { diameterMm: safeNumber(connection.diameterMm) } : {}),
      ...(connection.showDiameterLabel === false ? { showDiameterLabel: false } : {}),
      ...(connection.lengthM !== undefined ? { lengthM: safeNumber(connection.lengthM) } : {}),
      ...(Array.isArray(connection.labelAt) ? { labelAt: connection.labelAt } : {})
    }));

  return {
    devices,
    connections,
    settings: { ...defaultSettings, ...(data.settings || {}) },
    projectName: String(data.projectName || 'Dự án RAS'),
    view: {
      mode: data.view?.mode === '3d' ? '3d' : '2d',
      planZoom: Math.max(0.65, Math.min(1.8, safeNumber(data.view?.planZoom, 1))),
      camera3: data.view?.camera3 && typeof data.view.camera3 === 'object' ? data.view.camera3 : {}
    }
  };
}
