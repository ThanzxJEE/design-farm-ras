import { escNum, fmt } from './utils.js';
import { ROUND_TYPES } from './catalog.js';
import { calculatePipeHydraulics } from './hydraulics.js';

export function volumeOf(d){const p=d.params||{},water=Math.max(0,escNum(p.waterLevel,escNum(p.height,0)));if(d.type==='rectTank')return Math.max(0,escNum(p.width))*Math.max(0,escNum(p.depth))*water;if(ROUND_TYPES.has(d.type))return Math.PI*Math.pow(Math.max(0,escNum(p.diameter))/2,2)*water;return 0}

export function calculateSystem(devices, connections, settings){
 const dev=devices,s=settings;
 const tanks=dev.filter(d=>d.type==='fishTank'||d.type==='rectTank');
 const tankVolume=tanks.reduce((a,d)=>a+volumeOf(d),0);
 const otherVolumes=dev.filter(d=>['settlingTank','biofilter','storageTank','degassing'].includes(d.type)).reduce((a,d)=>a+volumeOf(d),0);
 const totalVolume=tankVolume+otherVolumes;
 const biomass=tanks.reduce((a,d)=>a+escNum(d.params.fishCount)*escNum(d.params.avgFishWeight),0);
 const feed=tanks.reduce((a,d)=>a+escNum(d.params.fishCount)*escNum(d.params.avgFishWeight)*escNum(d.params.feedRate,s.feedRate)/100,0);
 const turnover=Math.max(.05,escNum(s.turnoverHours,.5));
 // Turnover target applies to culture-tank working volume, not every vessel in the treatment loop.
 const flow=tankVolume/turnover;
 const settler=dev.find(d=>d.type==='settlingTank');
 const settlingVolume=settler?volumeOf(settler):0;
 const hrt=flow>0?settlingVolume/flow:0;
 const tan=feed*Math.max(0,escNum(s.tanPerKgFeed));
 const biofilters=dev.filter(d=>d.type==='biofilter');
 const bioVolume=biofilters.reduce((sum,b)=>sum+volumeOf(b),0);
 const mediaVol=biofilters.reduce((sum,b)=>sum+volumeOf(b)*Math.max(0,escNum(b.params.mediaFraction))/100,0);
 const tanCapacity=biofilters.reduce((sum,b)=>sum+volumeOf(b)*Math.max(0,escNum(b.params.mediaFraction))/100*Math.max(0,escNum(b.params.tanLoading)),0);
 const avgTanLoading=mediaVol>0?tanCapacity/mediaVol:0;
 const mediaRequired=avgTanLoading>0?tan/avgTanLoading:0;
 const avgMediaFraction=bioVolume>0?mediaVol/bioVolume:0;
 const bioTankRequired=avgMediaFraction>0?mediaRequired/avgMediaFraction:0;
 const bioSurface=biofilters.reduce((sum,b)=>sum+volumeOf(b)*Math.max(0,escNum(b.params.mediaFraction))/100*Math.max(0,escNum(b.params.specificSurfaceArea)),0);
 const avgSurface=mediaVol>0?bioSurface/mediaVol:0;
 const bioSurfaceRequired=mediaRequired*avgSurface;
 const pump=dev.find(d=>d.type==='pump');
 const qPump=pump?escNum(pump.params.ratedFlow):flow;
 const pipeHydraulics=calculatePipeHydraulics({flowM3h:flow,diameterM:s.pipeDiameter,pipeLengthM:s.pipeLength,frictionFactor:s.frictionFactor,minorK:s.minorK,staticHeadM:s.staticHead});
 const qM3s=pipeHydraulics.flowM3s;
 const area=pipeHydraulics.areaM2;
 const velocity=pipeHydraulics.velocityMps;
 const frictionHead=pipeHydraulics.frictionHeadM;
 const minorHead=pipeHydraulics.minorHeadM;
 const staticHead=pipeHydraulics.staticHeadM;
 const tdh=pipeHydraulics.totalDynamicHeadM;
 const efficiency=(pump?escNum(pump.params.efficiency,60):escNum(s.pumpEfficiency,60))/100;
 const hydraulic=1000*9.81*qM3s*tdh;
 const electrical=efficiency>0?hydraulic/efficiency/1000:0;
 const motorPower=pump?Math.max(0,escNum(pump.params.motorPower,0)):0;
 const oxygen=biomass*Math.max(0,escNum(s.oxygenConsumption,.35))*24/1000;
 const oxygenGap=Math.max(0,escNum(s.doTarget,6)-escNum(s.doCurrent,5.5));
 const oxygenDeficitKg=oxygenGap*totalVolume/1000;
 const oxygenUnit=dev.find(d=>d.type==='oxygenCone');
 const oxygenSourceUnit=dev.find(d=>d.type==='oxygenSource');
 const oxygenEta=Math.max(.01,escNum(oxygenUnit?.params.oxygenTransferEfficiency,s.oxygenEfficiency)/100);
 const oxygenSource=oxygen/oxygenEta;
 const oxygenRequiredPerHour=oxygenSource/24;
 const oxygenSourceCapacity=oxygenSourceUnit?Math.max(0,escNum(oxygenSourceUnit.params.capacity)):0;
 const uv=dev.some(d=>d.type==='uv');
 const blower=dev.find(d=>d.type==='blower');
 const degasser=dev.find(d=>d.type==='degassing');
 const sludgeTank=dev.find(d=>d.type==='sludgeTank');
 const warnings=[];
 if(!tanks.length)warnings.push({type:'error',text:'Chưa có bể nuôi cá để xác định thể tích và sinh khối.'});
 if(!pump)warnings.push({type:'warn',text:'Chưa bố trí máy bơm tuần hoàn.'});
 if(!settler)warnings.push({type:'warn',text:'Chưa có bể lắng/tách cặn thô; cần xác định giải pháp loại bỏ chất rắn.'});
 if((settler||dev.some(d=>d.type==='drumFilter'))&&!sludgeTank)warnings.push({type:'warn',text:'Chưa có bể thu bùn/nước rửa từ bể lắng và Drum Filter.'});
 if(!biofilters.length)warnings.push({type:'error',text:'Chưa có biofilter; chưa thể đánh giá tải TAN xử lý.'});
 if(!degasser)warnings.push({type:'warn',text:'Chưa có bộ khử khí CO₂ sau biofilter.'});
 if(!blower)warnings.push({type:'warn',text:'Chưa bố trí máy thổi khí cho bể vi sinh/bể nuôi.'});
 if(!oxygenUnit)warnings.push({type:'warn',text:'Chưa có côn hòa tan oxy; cần xác nhận phương án cấp oxy thay thế.'});
 if(oxygenUnit&&!oxygenSourceUnit)warnings.push({type:'error',text:'Côn hòa tan oxy chưa có nguồn O₂ tinh khiết được khai báo.'});
 if(oxygenSourceUnit&&oxygenSourceCapacity<oxygenRequiredPerHour)warnings.push({type:'error',text:`Nguồn O₂ khai báo ${fmt(oxygenSourceCapacity,3)} kg/h thấp hơn nhu cầu sơ bộ ${fmt(oxygenRequiredPerHour,3)} kg/h.`});
 if(connections.length===0&&dev.length>1)warnings.push({type:'warn',text:'Chưa có tuyến ống kết nối giữa các thiết bị.'});
 if(settler&&flow>0&&hrt<escNum(settler.params.designHRT))warnings.push({type:'error',text:`HRT bể lắng ${fmt(hrt*60,1)} phút thấp hơn mục tiêu ${fmt(escNum(settler.params.designHRT)*60,1)} phút.`});
 if(biofilters.length&&tan>tanCapacity)warnings.push({type:'error',text:`Tải TAN dự kiến ${fmt(tan,3)} kg/ngày vượt khả năng tổng của ${biofilters.length} biofilter (${fmt(tanCapacity,3)} kg/ngày).`});
 if(pump&&flow>qPump)warnings.push({type:'error',text:`Lưu lượng yêu cầu ${fmt(flow)} m³/h vượt lưu lượng định mức bơm ${fmt(qPump)} m³/h.`});
 if(pump&&motorPower>0&&motorPower<electrical*1.15)warnings.push({type:'error',text:`Công suất động cơ khai báo ${fmt(motorPower)} kW thấp hơn mức kiểm tra sơ bộ ${fmt(electrical*1.15)} kW.`});
 if(pump&&escNum(pump.params.head)>0&&tdh>escNum(pump.params.head))warnings.push({type:'warn',text:`TDH yêu cầu sơ bộ ${fmt(tdh)} m lớn hơn cột áp công bố của bơm ${fmt(pump.params.head)} m; cần đối chiếu đường đặc tính.`});
 if(velocity>escNum(s.maxVelocity,2))warnings.push({type:'warn',text:`Vận tốc ống chính ${fmt(velocity)} m/s vượt ngưỡng cấu hình ${fmt(s.maxVelocity)} m/s.`});
 if(frictionHead+minorHead>escNum(s.maxHeadLoss,5))warnings.push({type:'warn',text:`Tổn thất dọc + cục bộ sơ bộ ${fmt(frictionHead+minorHead)} m vượt ngưỡng cấu hình.`});
 const bioBranchFlow=biofilters.length?flow/biofilters.length:flow;
 for(const d of dev){
  if(d.params?.ratedFlow){const qDesign=d.type==='biofilter'?bioBranchFlow:flow;if(qDesign>escNum(d.params.ratedFlow))warnings.push({type:'warn',text:`${d.name}: lưu lượng kiểm tra ${fmt(qDesign)} m³/h lớn hơn năng lực tham khảo ${fmt(d.params.ratedFlow)} m³/h.`})}
 }
 const connected=new Set();for(const c of connections){connected.add(c.from);connected.add(c.to)}
 for(const d of dev){if(!connected.has(d.id))warnings.push({type:'warn',text:`${d.name} chưa được nối vào sơ đồ đường ống.`})}
 const errors=warnings.filter(w=>w.type==='error').length;
 return {tankVolume,otherVolumes,totalVolume,biomass,feed,flow,settlingVolume,hrt,tan,motorPower,oxygenSourceCapacity,oxygenRequiredPerHour,bioVolume,bioCount:biofilters.length,mediaVol,tanCapacity,mediaRequired,bioTankRequired,bioSurface,bioSurfaceRequired,qPump,velocity,frictionHead,minorHead,staticHead,tdh,hydraulic,electrical,oxygen,oxygenGap,oxygenDeficitKg,oxygenSource,oxygenEta,warnings,status:errors?'Không phù hợp':warnings.length?'Cần kiểm tra':'Bình thường',tanks:tanks.length,deviceCount:dev.length,uv}
}
