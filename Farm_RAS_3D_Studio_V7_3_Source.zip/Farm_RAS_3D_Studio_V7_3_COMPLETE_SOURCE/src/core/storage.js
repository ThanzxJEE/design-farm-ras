// Adapter an toàn cho localStorage: mọi thao tác đều có try/catch vì trình duyệt
// có thể chặn storage trong chế độ riêng tư hoặc khi hết quota.
export function readJSONStorage(key, fallback = null, storage = globalThis.localStorage) {
  try {
    if (!storage) return fallback;
    const raw = storage.getItem(key);
    return raw == null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

export function writeJSONStorage(key, value, storage = globalThis.localStorage) {
  try {
    if (!storage) return false;
    storage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export function removeStorageItem(key, storage = globalThis.localStorage) {
  try {
    if (!storage) return false;
    storage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}
