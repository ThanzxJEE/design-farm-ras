// Danh mục thiết bị, giá trị mặc định và trường nhập liệu của Farm RAS.
export const CATALOG = [
 {type:'fishTank',name:'Bể cá tròn',en:'Fish Tank',icon:'◉',group:'Bể & xử lý nước',color:'#68bfc0',defaults:{diameter:2.5,height:1.2,waterLevel:.8,fishCount:500,avgFishWeight:.3,feedRate:1.5,ratedFlow:10}},
 {type:'rectTank',name:'Bể cá chữ nhật',en:'Rectangular Tank',icon:'▭',group:'Bể & xử lý nước',color:'#73b7c6',defaults:{width:3,depth:2,height:1.2,waterLevel:1,fishCount:400,avgFishWeight:.25,feedRate:1.5,ratedFlow:10}},
 {type:'settlingTank',name:'Bể lắng',en:'Settling Tank',icon:'◍',group:'Bể & xử lý nước',color:'#c6a46b',defaults:{diameter:1.25,height:1.5,waterLevel:1.4,designHRT:.2,ratedFlow:10}},
 {type:'drumFilter',name:'Drum filter',en:'Drum Filter',icon:'▤',group:'Bể & xử lý nước',color:'#6a9fb5',defaults:{width:1.2,depth:.8,height:.95,ratedFlow:12,meshMicron:60}},
 {type:'mechanicalFilter',name:'Lọc cơ học',en:'Mechanical Filter',icon:'▥',group:'Bể & xử lý nước',color:'#8ca9a8',defaults:{width:1,depth:.7,height:.9,ratedFlow:10}},
 {type:'biofilter',name:'Lọc vi sinh Kaldnes',en:'Moving Bed Biofilter',icon:'❋',group:'Bể & xử lý nước',color:'#6ea98a',defaults:{diameter:1,height:1.3,waterLevel:1.1,mediaFraction:50,specificSurfaceArea:500,tanLoading:.1,ratedFlow:4}},
 {type:'storageTank',name:'Bể chứa nước',en:'Storage Tank',icon:'◉',group:'Bể & xử lý nước',color:'#76a9c7',defaults:{diameter:1.2,height:1.2,waterLevel:.9,ratedFlow:10}},
 {type:'sludgeTank',name:'Bể thu bùn',en:'Sludge Collection Tank',icon:'◍',group:'Bể & xử lý nước',color:'#9a806f',defaults:{diameter:.8,height:.9,waterLevel:.45}},
 {type:'degassing',name:'Tháp khử khí',en:'Degassing Unit',icon:'≋',group:'Bể & xử lý nước',color:'#7eae9e',defaults:{diameter:.9,height:1.5,waterLevel:1.1,ratedFlow:10}},
 {type:'pump',name:'Bơm tuần hoàn',en:'Water Pump',icon:'✥',group:'Thiết bị vận hành',color:'#6c9dbb',defaults:{width:.75,depth:.56,height:.55,ratedFlow:10,head:4,efficiency:60,motorPower:.25}},
 {type:'blower',name:'Máy sục khí',en:'Air Blower',icon:'≋',group:'Thiết bị vận hành',color:'#a38dbb',defaults:{width:.7,depth:.45,height:.45,power:.37,airFlow:120,airPressure:20}},
 {type:'oxygenCone',name:'Côn hòa tan oxy',en:'Oxygen Cone',icon:'▽',group:'Thiết bị vận hành',color:'#70b8c4',defaults:{diameter:.5,height:1.2,ratedFlow:10,oxygenTransferEfficiency:70}},
 {type:'oxygenSource',name:'Nguồn oxy tinh khiết',en:'Oxygen Supply',icon:'O₂',group:'Thiết bị vận hành',color:'#67aeb9',defaults:{diameter:.38,height:1.1,waterLevel:.08,capacity:.12}},
 {type:'uv',name:'Đèn UV',en:'UV Sterilizer',icon:'☼',group:'Thiết bị vận hành',color:'#9b91bf',defaults:{width:.9,depth:.25,height:.3,ratedFlow:10,power:.12}},
 {type:'valve',name:'Van điều khiển',en:'Valve',icon:'⊗',group:'Đường ống & phụ kiện',color:'#c6a16f',defaults:{width:.25,depth:.25,height:.2}},
 {type:'pipe',name:'Đoạn ống rời',en:'Pipe Segment',icon:'━',group:'Đường ống & phụ kiện',color:'#5aaeb5',defaults:{diameter:.09,length:2,roughness:.0000015}}
];
export const byType = type => CATALOG.find(x=>x.type===type);
export const ROUND_TYPES = new Set(['fishTank','settlingTank','biofilter','storageTank','degassing','oxygenSource','sludgeTank']);
export const VOLUME_TYPES = new Set(['fishTank','rectTank','settlingTank','biofilter','storageTank','degassing']);
export const FIELDS = {
 fishTank:[['diameter','Đường kính bể','m',.05],['height','Chiều cao thành bể','m',.05],['waterLevel','Mực nước thực tế','m',.05],['fishCount','Số lượng cá','con',1],['avgFishWeight','Khối lượng TB/con','kg',.01],['feedRate','Tỷ lệ thức ăn/ngày','%',.1],['ratedFlow','Lưu lượng giới hạn','m³/h',.5]],
 rectTank:[['width','Chiều dài bể','m',.05],['depth','Chiều rộng bể','m',.05],['height','Chiều cao thành bể','m',.05],['waterLevel','Mực nước thực tế','m',.05],['fishCount','Số lượng cá','con',1],['avgFishWeight','Khối lượng TB/con','kg',.01],['feedRate','Tỷ lệ thức ăn/ngày','%',.1],['ratedFlow','Lưu lượng giới hạn','m³/h',.5]],
 settlingTank:[['diameter','Đường kính bể','m',.05],['height','Chiều cao bể','m',.05],['waterLevel','Mực nước','m',.05],['designHRT','HRT mục tiêu','giờ',.05],['ratedFlow','Lưu lượng thiết kế','m³/h',.5]],
 drumFilter:[['width','Chiều dài','m',.05],['depth','Chiều rộng','m',.05],['height','Chiều cao','m',.05],['ratedFlow','Công suất lưu lượng','m³/h',.5],['meshMicron','Kích thước lưới','µm',5]],
 mechanicalFilter:[['width','Chiều dài','m',.05],['depth','Chiều rộng','m',.05],['height','Chiều cao','m',.05],['ratedFlow','Lưu lượng thiết kế','m³/h',.5]],
 biofilter:[['diameter','Đường kính bể lọc','m',.05],['height','Chiều cao bể','m',.05],['waterLevel','Mực nước','m',.05],['mediaFraction','Tỷ lệ vật liệu lọc','%',1],['specificSurfaceArea','Diện tích bề mặt riêng','m²/m³',10],['tanLoading','Tải TAN thiết kế','kg TAN/m³ vật liệu/ngày',.01],['ratedFlow','Lưu lượng thiết kế','m³/h',.5]],
 storageTank:[['diameter','Đường kính','m',.05],['height','Chiều cao','m',.05],['waterLevel','Mực nước','m',.05],['ratedFlow','Lưu lượng thiết kế','m³/h',.5]],
 sludgeTank:[['diameter','Đường kính bể','m',.05],['height','Chiều cao bể','m',.05],['waterLevel','Mực bùn/nước tham chiếu','m',.05]],
 degassing:[['diameter','Đường kính','m',.05],['height','Chiều cao','m',.05],['waterLevel','Mực nước','m',.05],['ratedFlow','Lưu lượng thiết kế','m³/h',.5]],
 pump:[['width','Chiều dài','m',.05],['depth','Chiều rộng','m',.05],['height','Chiều cao','m',.05],['ratedFlow','Lưu lượng định mức','m³/h',.5],['head','Cột áp bơm công bố','m',.1],['efficiency','Hiệu suất tổng','%',1],['motorPower','Công suất động cơ','kW',.01]],
 blower:[['width','Chiều dài','m',.05],['depth','Chiều rộng','m',.05],['height','Chiều cao','m',.05],['power','Công suất điện','kW',.05],['airFlow','Lưu lượng khí tại áp suất làm việc','L/min',1],['airPressure','Áp suất làm việc','kPa',1]],
 oxygenCone:[['diameter','Đường kính','m',.05],['height','Chiều cao','m',.05],['ratedFlow','Lưu lượng nước','m³/h',.5],['oxygenTransferEfficiency','Hiệu suất chuyển oxy','%',1]],
 oxygenSource:[['diameter','Đường kính bình / cụm','m',.01],['height','Chiều cao','m',.05],['capacity','Năng lực cấp O₂','kg/h',.01]],
 uv:[['width','Chiều dài','m',.05],['depth','Chiều rộng','m',.05],['height','Chiều cao','m',.05],['ratedFlow','Lưu lượng tối đa','m³/h',.5],['power','Công suất đèn','kW',.01]],
 valve:[['width','Chiều dài','m',.05],['depth','Chiều rộng','m',.05],['height','Chiều cao','m',.05]],
 pipe:[['diameter','Đường kính trong','m',.005],['length','Chiều dài','m',.1],['roughness','Độ nhám tuyệt đối','m',.00001]]
};
