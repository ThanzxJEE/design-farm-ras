// Hình học cổng thiết bị và tuyến ống 2D. Hai đầu ống bám theo hình dạng thiết bị.
import { escNum } from './utils.js';
export function devicePipePort(device,toward,roundTypes){
 const dx=Number(toward?.[0])-device.x,dz=Number(toward?.[1])-device.z;
 if(!Number.isFinite(dx)||!Number.isFinite(dz)||Math.hypot(dx,dz)<1e-7)return [device.x,device.z];
 const p=device.params||{};
 if(roundTypes.has(device.type)||device.type==='pump'){
  const r=device.type==='pump'?Math.max(.3,escNum(p.width,.75),escNum(p.depth,.55))/2:Math.max(.22,escNum(p.diameter,1)/2);
  const len=Math.hypot(dx,dz);return [device.x+dx/len*r,device.z+dz/len*r];
 }
 const hw=Math.max(.2,escNum(p.width,.8)/2),hh=Math.max(.175,escNum(p.depth,.55)/2),angle=escNum(device.rotation);
 const ca=Math.cos(angle),sa=Math.sin(angle);
 // Transform direction into the device's unrotated local coordinates.
 const lx=ca*dx+sa*dz,lz=-sa*dx+ca*dz;
 const tx=Math.abs(lx)>1e-9?hw/Math.abs(lx):Infinity;
 const tz=Math.abs(lz)>1e-9?hh/Math.abs(lz):Infinity;
 const scale=Math.min(tx,tz);
 const bx=lx*scale,bz=lz*scale;
 // Transform the boundary point back to world coordinates.
 return [device.x+ca*bx-sa*bz,device.z+sa*bx+ca*bz];
}
export function buildPipeRoute(c,devices,roundTypes){
 const a=devices.find(x=>x.id===c.from),b=devices.find(x=>x.id===c.to);if(!a||!b)return [];
 let pts;
 if(Array.isArray(c.route)&&c.route.length>=2){pts=c.route.map(p=>[Number(p[0]),Number(p[1])]);}
 else {
  const dx=b.x-a.x,dz=b.z-a.z;
  const pa=devicePipePort(a,[b.x,b.z],roundTypes),pb=devicePipePort(b,[a.x,a.z],roundTypes);
  // Orthogonal auto-route between the actual device ports.
  if(Math.abs(dx)>=Math.abs(dz)){const mid=(pa[0]+pb[0])/2;pts=[pa,[mid,pa[1]],[mid,pb[1]],pb];}
  else {const mid=(pa[1]+pb[1])/2;pts=[pa,[pa[0],mid],[pb[0],mid],pb];}
 }
 if(pts.length<2)return [];
 // Recalculate both ends every render. Moving either device therefore keeps
 // the pipe connected while preserving user-created bends in the middle.
 const firstInner=pts.length>2?pts[1]:[b.x,b.z];
 const lastInner=pts.length>2?pts[pts.length-2]:[a.x,a.z];
 pts[0]=devicePipePort(a,firstInner,roundTypes);
 pts[pts.length-1]=devicePipePort(b,lastInner,roundTypes);
 return pts;
}
export function measurePipeLength(c,devices,roundTypes){if(Number.isFinite(Number(c.lengthM))&&Number(c.lengthM)>0)return Number(c.lengthM);const pts=buildPipeRoute(c,devices,roundTypes);let total=0;for(let i=1;i<pts.length;i++)total+=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);return total}
