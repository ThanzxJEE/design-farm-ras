// Các hàm tiện ích thuần dùng chung trong ứng dụng.
export const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[ch]));

export const fmt = (value, digits = 2) => Number.isFinite(Number(value))
  ? Number(value).toLocaleString('vi-VN', { minimumFractionDigits: digits, maximumFractionDigits: digits })
  : '—';

export const uid = () => `ras-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

export const escNum = (value, fallback = 0) => {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
};

export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, Number(value) || 0));
}
